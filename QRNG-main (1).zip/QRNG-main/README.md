https://phet.colorado.edu/sims/cheerpj/quantum-tunneling/latest/quantum-tunneling.html?simulation=quantum-tunneling

![image](https://github.com/user-attachments/assets/ade0e7be-e63d-4fda-972d-9c5833a8fccb)
![image](https://github.com/user-attachments/assets/4c329115-1800-421f-8341-ed099fafb4ce)
![{0470FB48-56C5-43BA-9814-FE3FEACC33FB}](https://github.com/user-attachments/assets/8a5e80e6-f59b-4979-a55f-b9938f57a15f)
![{6067A539-DF4E-43DA-A3B8-E677ADCEF0E7}](https://github.com/user-attachments/assets/e4a56b5c-ddf7-4802-bcdb-bade8825b0fd)
![{A047690F-2080-414E-AF9F-D98509DDA39F}](https://github.com/user-attachments/assets/ebbd7c80-f3c7-40b1-a8d6-14da1e7e41c6)

![image](https://github.com/user-attachments/assets/92084c83-34a6-445c-8d61-7e93340ef0ca)
![image](https://github.com/user-attachments/assets/d3fa6397-b180-4ff4-9c5f-2dac2df8544a)
